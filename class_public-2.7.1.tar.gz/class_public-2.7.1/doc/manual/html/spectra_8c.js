var spectra_8c =
[
    [ "spectra_cl_at_l", "spectra_8c.html#a474a08a4d11642f6e688524556442909", null ],
    [ "spectra_pk_at_z", "spectra_8c.html#a3a628fdd2920efe84eb4343525e4c23c", null ],
    [ "spectra_pk_at_k_and_z", "spectra_8c.html#abbacb8b60693f02f2f0e37fd76c6bdcb", null ],
    [ "spectra_pk_nl_at_z", "spectra_8c.html#a459a1ded2ca25cd5d1e4e315bdd1175a", null ],
    [ "spectra_pk_nl_at_k_and_z", "spectra_8c.html#a0e6c6722e9cfa606803aa637fb126d34", null ],
    [ "spectra_tk_at_z", "spectra_8c.html#ab59220fbc82fe2fa2997105af4d68187", null ],
    [ "spectra_tk_at_k_and_z", "spectra_8c.html#a99c7fafb33b166530fc1a9206feb453f", null ],
    [ "spectra_init", "spectra_8c.html#a192c3cc36d17f276ed7b5d7e485e70f1", null ],
    [ "spectra_free", "spectra_8c.html#acbfeac6ad88fa757677b47d76722aec3", null ],
    [ "spectra_indices", "spectra_8c.html#ab9a34eea930c566c6b47cc79da887853", null ],
    [ "spectra_cls", "spectra_8c.html#aff413243f74650e6eba56225ef30fb81", null ],
    [ "spectra_compute_cl", "spectra_8c.html#a202211a45920a13d8f0f0d545e45b226", null ],
    [ "spectra_k_and_tau", "spectra_8c.html#a80e1413144a57366bbf279a2ae6a0028", null ],
    [ "spectra_pk", "spectra_8c.html#a1a6dd87098ad3da12ff3a685a6e32010", null ],
    [ "spectra_sigma", "spectra_8c.html#aad251bcc29d8eee1448d01e30260eb4a", null ],
    [ "spectra_matter_transfers", "spectra_8c.html#a5c100c52fd6479fee1c477d9fd841f28", null ],
    [ "spectra_output_tk_data", "spectra_8c.html#a4cf287a8b3796656614e40b9132f1176", null ],
    [ "spectra_fast_pk_at_kvec_and_zvec", "spectra_8c.html#ac729eace6e5ce72dffea9090fb94f9e2", null ]
];