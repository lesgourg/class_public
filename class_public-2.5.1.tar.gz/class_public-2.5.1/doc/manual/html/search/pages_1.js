var searchData=
[
  ['the_20_60external_5fpk_60_20mode',['The `external_Pk` mode',['../md__home_deannah88_Documents_Uni_stuff_Master_Student_Job_class_doxygen_class_external_Pk_README.html',1,'']]]
];
