var NAVTREE =
[
  [ "CLASS MANUAL", "index.html", [
    [ "CLASS: Cosmic Linear Anisotropy Solving System", "index.html", null ],
    [ "Where to find information and documentation on CLASS?", "md_chap2.html", null ],
    [ "CLASS: Cosmic Linear Anisotropy Solving System", "md_chap3.html", null ],
    [ "The `external_Pk` mode", "md__home_deannah88_Documents_Uni_stuff_Master_Student_Job_class_doxygen_class_external_Pk_README.html", null ],
    [ "Updating the manual", "md_mod.html", null ],
    [ "Data Structures", null, [
      [ "Data Structures", "annotated.html", "annotated" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"common_8h.html#aa6bf73c3bb587fcaf367ac9d43798bcd",
"output_8h_source.html",
"perturbations_8h.html#adda35d646eba2eabc09a21861effb845",
"spectra_8h.html#a82a56f7919678728f1a9b695deabc104",
"transfer_8h.html#a103c59aede115134d0063b78081b3075"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';