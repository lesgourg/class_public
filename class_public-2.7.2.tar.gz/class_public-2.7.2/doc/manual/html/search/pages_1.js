var searchData=
[
  ['the_20_60external_5fpk_60_20mode',['The `external_Pk` mode',['../md__Users_lesgourg_OwnCloud_documents_codes_ClassProject_class_external_Pk_README.html',1,'']]]
];
