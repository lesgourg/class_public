var searchData=
[
  ['f1',['f1',['../thermodynamics_8h.html#af26abb8c819fd3cf4d6cb0711c80b9ee',1,'thermodynamics.h']]],
  ['f2',['f2',['../thermodynamics_8h.html#a5cd67c8452696b8eebb34709acc71f36',1,'thermodynamics.h']]],
  ['f_5fbi',['f_bi',['../primordial_8h.html#a39effc6417460af3d49d9bdfadc4e9ba',1,'primordial']]],
  ['f_5fcdi',['f_cdi',['../primordial_8h.html#aa8472691ad4a9e278ef4204b4ded7f39',1,'primordial']]],
  ['f_5fnid',['f_nid',['../primordial_8h.html#a355f4f1a0f3d07dd585afd90be0d5f33',1,'primordial']]],
  ['f_5fniv',['f_niv',['../primordial_8h.html#a5c8bfaf9d87e936f5f2d1732e2bdb2ea',1,'primordial']]],
  ['factor_5fncdm',['factor_ncdm',['../background_8h.html#a96b570d10c77a6fc4ca09759ed233906',1,'background']]],
  ['fhe',['fHe',['../thermodynamics_8h.html#abd42dddfc07621c1934035dce015ade4',1,'recombination']]],
  ['file_5fformat',['file_format',['../common_8h.html#abd81d11867ad50357ea8332e8d36cf8a',1,'common.h']]],
  ['fu',['fu',['../thermodynamics_8h.html#ae23d85a5262d4ff6121889e3b38bb4ed',1,'recombination']]]
];
