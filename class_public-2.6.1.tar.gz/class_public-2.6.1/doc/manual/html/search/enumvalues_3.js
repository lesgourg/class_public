var searchData=
[
  ['synchronous',['synchronous',['../perturbations_8h.html#a393651984401ac059c225aed80e4862ca3c4f1195e4f20a93dc90b64f268687c1',1,'perturbations.h']]]
];
