var searchData=
[
  ['perturbations_2ec',['perturbations.c',['../perturbations_8c.html',1,'']]],
  ['perturbations_2eh',['perturbations.h',['../perturbations_8h.html',1,'']]],
  ['primordial_2ec',['primordial.c',['../primordial_8c.html',1,'']]],
  ['primordial_2eh',['primordial.h',['../primordial_8h.html',1,'']]]
];
