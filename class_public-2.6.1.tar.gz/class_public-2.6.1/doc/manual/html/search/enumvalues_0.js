var searchData=
[
  ['delta_5fbc_5fsquared',['delta_bc_squared',['../common_8h.html#aab161982846c9e414cccea37822f4b0ca3ac991356a90d7ef50cf06f2e287939e',1,'common.h']]],
  ['delta_5fm_5fsquared',['delta_m_squared',['../common_8h.html#aab161982846c9e414cccea37822f4b0cadf09cc6e3587e8d8f58386df9305c6ce',1,'common.h']]],
  ['delta_5ftot_5ffrom_5fpoisson_5fsquared',['delta_tot_from_poisson_squared',['../common_8h.html#aab161982846c9e414cccea37822f4b0ca8406d31036bb2d430753210d3270f7b2',1,'common.h']]],
  ['delta_5ftot_5fsquared',['delta_tot_squared',['../common_8h.html#aab161982846c9e414cccea37822f4b0caad4f0a8f52a0e789973f85d0351d359b',1,'common.h']]]
];
