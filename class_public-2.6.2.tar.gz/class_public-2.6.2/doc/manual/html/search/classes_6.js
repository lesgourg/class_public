var searchData=
[
  ['spectra',['spectra',['../spectra_8h.html#structspectra',1,'']]]
];
